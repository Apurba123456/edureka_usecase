package com.usecase.Payment.subscriber;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.usecase.Payment.entity.Payment;
import com.usecase.Payment.service.UserService;

@Component
@RabbitListener(queues="googlepay")
public class Subscriber {
	
	
	Gson gson=new Gson();
	
	@Autowired
	UserService userservice;
	
	@RabbitHandler
		public void receive(String user) {
		
		Payment pay=gson.fromJson(user,Payment.class);
		userservice.save(pay);
	}

}