package com.usecase.Payment.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="user_payment_mode")
public class Payment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	
	@Column(name="userid")
	String userid;
	
	@Column(name="channel")
	String channel;
	
	@Column(name="amount")
	Double amount;

	public Payment(int id, String userid, String channel, Double amount) {
		super();
		this.id = id;
		this.userid = userid;
		this.channel = channel;
		this.amount = amount;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUser(String userid) {
		this.userid = userid;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Payment [id=" + id + ", userid=" + userid + ", channel=" + channel + ", amount=" + amount + "]";
	}
	
	

}
