package com.usecase.Payment.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usecase.Payment.entity.Payment;
import com.usecase.Payment.repository.UserRepo;
import com.usecase.Payment.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepo userrepo;

	@Override
	public void save(Payment user) {
		userrepo.save(user);

	}

	@Override
	public List<Payment> findAll() {
		return userrepo.findAll();
	}

	@Override
	public Payment findById(int id) {
		return userrepo.findById(id).get();
	}

	@Override
	public void deleteById(int id) {
		userrepo.deleteById(id);

	}

	@Override
	public List<Payment> findByChannel(String channel) {
		return userrepo.findByChannel(channel);
	}

	@Override
	public List<Payment> findByUseridAndChannel(String userid, String channel) {
		return userrepo.findByUseridAndChannel(userid, channel);
	}

}
