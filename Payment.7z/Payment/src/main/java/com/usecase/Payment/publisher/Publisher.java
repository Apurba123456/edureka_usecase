package com.usecase.Payment.publisher;

import java.util.List;
import com.google.gson.Gson;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.usecase.Payment.entity.Payment;
import com.usecase.Payment.service.UserService;

@RestController
public class Publisher {
	@Autowired
	RabbitTemplate template;
	
	@Autowired
	Queue queue;
	
	@Autowired
	UserService userservice;

    Publisher(Queue queue) {
        this.queue = queue;
    }
	
	@PostMapping ("/pay")
	void sendMessage(@RequestBody Payment payment)
	{
		Gson gson=new Gson();
		System.out.println(payment);
		this.template.convertAndSend("MyExchange",payment.getChannel(),gson.toJson(payment));
		System.out.println("[x] Sent '"+payment+"'");
	}
	
	@GetMapping ("/pay")
	List<Payment> findAll() {
		return userservice.findAll();
	}
	
	@GetMapping ("/pay/{id}")
	Payment findById(@PathVariable int id) {
		return userservice.findById(id);
	}
	
	@GetMapping ("/pay/channel/{channel}")
	List<Payment> findByChannel(@PathVariable String channel) {
		return userservice.findByChannel(channel);
	}
	
	@GetMapping("/pay/{user}/{channel}")
	List<Payment> findByUseridAndChannel(@PathVariable String user, @PathVariable String  channel)
	{
		return userservice.findByUseridAndChannel(user,channel);
		
	}
	
	
	
	
	

}

