package com.usecase.Payment.config;

import org.springframework.context.annotation.Configuration;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@Configuration
public class AppConfig {
	
	@Bean
	@Primary
	Queue getQueue() {
		return new Queue("phonepay");
	}
	
	@Bean
	Queue getQueue1() {
		return new Queue("googlepay");
	}

}
